const domain = ''

const APIs = {
}

const responseCode = {
  success: '',
  error: '',
  tokenTimeout: ''
}

export {
  domain,
  APIs,
  responseCode
}
