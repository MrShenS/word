const plugin = {
  pluginList: [
  ]
}

export default plugin
