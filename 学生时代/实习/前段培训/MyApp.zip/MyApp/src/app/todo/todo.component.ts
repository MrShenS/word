import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.less']
})
export class TodoComponent implements OnInit {

  newTodo = {
    todoContent: ''
  };
  todoList = [];
  filter = {
    filterTodoList: [],
    filterStatus: '' // ALL COMPLETE ACTIVE
  };
  constructor() { }

  ngOnInit() {

  }

  addTodo(event) {
    if (event.keyCode === 13) {
      this.todoList = [
        {
          index: this.todoList.length,
          todoContent: this.newTodo.todoContent,
          status: 'ACTIVE',
          edit: false
        },
        ...this.todoList
      ];
      this.newTodo.todoContent = '';
    }
  }

  changeTodoStatus(event, todo) {
    todo.status = event.target.checked ? 'COMPLETE' : 'ACTIVE';
  }

  deleteTodo(index) {
    this.todoList.splice(index , 1);
  }

  getActiveCount() {
    return this.todoList.filter((todo) => {
      return todo.status === 'ACTIVE';
    }).length ;
  }

  filterTodo(status) {
    this.filter.filterStatus = status;
    this.todoList.forEach((todo, index) => {
      todo.index = index;
    });
    if (this.filter.filterStatus === 'COMPLETE') {
      this.filter.filterTodoList = this.todoList.filter((todo) => {return todo.status === 'COMPLETE'});
    } else if (this.filter.filterStatus === 'ACTIVE') {
      this.filter.filterTodoList = this.todoList.filter((todo) => {return todo.status === 'ACTIVE'});
    } else {
      this.filter.filterTodoList = this.todoList;
    }
    return this.filter.filterTodoList;
  }
}
