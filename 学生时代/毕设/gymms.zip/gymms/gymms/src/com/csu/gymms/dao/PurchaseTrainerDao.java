package com.csu.gymms.dao;

public interface PurchaseTrainerDao {
	
	void insertPurchaseTrainer(Object obj);

}
