package com.csu.gymms.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.csu.gymms.entity.CardInfoBean;
import com.csu.gymms.entity.PurchaseTrainerBean;
import com.csu.gymms.service.CardInfoService;
import com.csu.gymms.service.CoachInfoService;
import com.csu.gymms.service.PurchaseTrainerService;

public class PurchaseTrainerServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public PurchaseTrainerServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String cardid = request.getParameter("cardid");
		
		String id = request.getParameter("id");
		ArrayList cardlist = new CardInfoService().getCardInfo();
		ArrayList coachlist = new CoachInfoService().getCoachInfo();
		request.getSession().setAttribute("clist", coachlist);
		for(int i = 0; i < cardlist.size(); i++) {
			CardInfoBean cib = (CardInfoBean)cardlist.get(i);
			if(cib.getCardid().equals(cardid)) {
				
				request.getSession().setAttribute("cib",cib);				
				if("trainer".equals(id)) {
					
					response.sendRedirect("personal_trainer1.jsp");
				}
				break;
			}
		}
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		
		PurchaseTrainerBean ptb = new PurchaseTrainerBean();
		ptb.setCardid(request.getParameter("cardid"));
		
		String cardtype = request.getParameter("cardtype");
		if("�꿨".equals(cardtype)){
			ptb.setCardtype("1");
		}
		if("���꿨".equals(cardtype)){
			ptb.setCardtype("2");
		}
		if("����".equals(cardtype)){
			ptb.setCardtype("3");
		}
		if("�¿�".equals(cardtype)){
			ptb.setCardtype("4");
		}
		if("�ο�".equals(cardtype)){
			ptb.setCardtype("5");
		}
		
		ptb.setMname(request.getParameter("mname"));
		ptb.setCoursename(request.getParameter("coursename"));
		ptb.setMoney(request.getParameter("money"));
		ptb.setCoachname(request.getParameter("coachname"));
		ptb.setContent(request.getParameter("content"));
		
		PurchaseTrainerService pts = new PurchaseTrainerService();
		pts.insertPurchaseTrainer(ptb);
		request.getRequestDispatcher("personal_trainer2.jsp").forward(request, response);
		
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
