package com.csu.gymms.entity;

public class DeviceInfoBean {
	
	private String deviceid;
	private String devicename;
	private String principal;
	private String room;
	private String entrancetime;
	private String usetime;
	private String brief;
	public String getDeviceid() {
		return deviceid;
	}
	public void setDeviceid(String deviceid) {
		this.deviceid = deviceid;
	}
	public String getDevicename() {
		return devicename;
	}
	public void setDevicename(String devicename) {
		this.devicename = devicename;
	}
	public String getPrincipal() {
		return principal;
	}
	public void setPrincipal(String principal) {
		this.principal = principal;
	}
	public String getRoom() {
		return room;
	}
	public void setRoom(String room) {
		this.room = room;
	}
	public String getEntrancetime() {
		return entrancetime;
	}
	public void setEntrancetime(String entrancetime) {
		this.entrancetime = entrancetime;
	}
	public String getUsetime() {
		return usetime;
	}
	public void setUsetime(String usetime) {
		this.usetime = usetime;
	}
	public String getBrief() {
		return brief;
	}
	public void setBrief(String brief) {
		this.brief = brief;
	}
	
	

}
