package com.csu.gymms.entity;

public class OperateDateBean {
	
	private String ope_id;
	private String ope_name;
	private String function;
	private String ope_date;
	private String specific_ope;
	
	public String getOpe_id() {
		return ope_id;
	}
	public void setOpe_id(String ope_id) {
		this.ope_id = ope_id;
	}
	public String getOpe_name() {
		return ope_name;
	}
	public void setOpe_name(String ope_name) {
		this.ope_name = ope_name;
	}
	public String getFunction() {
		return function;
	}
	public void setFunction(String function) {
		this.function = function;
	}
	public String getOpe_date() {
		return ope_date;
	}
	public void setOpe_date(String ope_date) {
		this.ope_date = ope_date;
	}
	public String getSpecific_ope() {
		return specific_ope;
	}
	public void setSpecific_ope(String specific_ope) {
		this.specific_ope = specific_ope;
	}
	
}
