package com.csu.gymms.util;

public class NullChartException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NullChartException() {
		super();
	}

	public NullChartException(String arg0) {
		super(arg0);
	}
    
	
}
