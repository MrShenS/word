package com.csu.gymms.dao;

public interface PageOperationDao {
 
	public String CreatePageSql();
	public String CreateNextPageSql();
	public String CreatePrePageSql();
}
