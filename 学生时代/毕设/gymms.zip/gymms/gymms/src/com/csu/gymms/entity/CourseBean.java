package com.csu.gymms.entity;

public class CourseBean {
	
	private String courseid;
	private String coursename;
	private String roomname;
	private String coachname;
	private String carpnumber;
	private String numberhas;
	private String devicename;
	private String benifits;
	
	public String getCourseid() {
		return courseid;
	}
	public void setCourseid(String courseid) {
		this.courseid = courseid;
	}
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public String getRoomname() {
		return roomname;
	}
	public void setRoomname(String roomname) {
		this.roomname = roomname;
	}
	public String getCoachname() {
		return coachname;
	}
	public void setCoachname(String coachname) {
		this.coachname = coachname;
	}
	public String getCarpnumber() {
		return carpnumber;
	}
	public void setCarpnumber(String carpnumber) {
		this.carpnumber = carpnumber;
	}
	public String getNumberhas() {
		return numberhas;
	}
	public void setNumberhas(String numberhas) {
		this.numberhas = numberhas;
	}
	public String getDevicename() {
		return devicename;
	}
	public void setDevicename(String devicename) {
		this.devicename = devicename;
	}
	public String getBenifits() {
		return benifits;
	}
	public void setBenifits(String benifits) {
		this.benifits = benifits;
	}
	
	

}
