package com.csu.gymms.entity;

public class FieldInfoBean {
	
	private String roomid;
	
	private String roomname;
	
	private String accountnumber;
	
	private String roomphoto;

	public String getRoomid() {
		return roomid;
	}

	public void setRoomid(String roomid) {
		this.roomid = roomid;
	}

	public String getRoomname() {
		return roomname;
	}

	public void setRoomname(String roomname) {
		this.roomname = roomname;
	}

	public String getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}

	public String getRoomphoto() {
		return roomphoto;
	}

	public void setRoomphoto(String roomphoto) {
		this.roomphoto = roomphoto;
	}
}
